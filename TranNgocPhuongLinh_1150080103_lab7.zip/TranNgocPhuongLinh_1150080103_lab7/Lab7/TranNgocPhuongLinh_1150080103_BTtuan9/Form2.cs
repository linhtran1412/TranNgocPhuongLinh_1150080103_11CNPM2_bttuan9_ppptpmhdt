﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_BTtuan9
{
    public partial class Form2 : Form
    {
        string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\pppt-pmhdt-c#\Lab7\TranNgocPhuongLinh_1150080103_BTtuan9\QuanLyBanSach.mdf;Integrated Security=True";

        SqlConnection sqlCon = null;
        SqlDataAdapter adapter = null;
        DataSet ds = null;

        public Form2()
        {
            InitializeComponent();
        }

        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void LoadData()
        {
            MoKetNoi();
            string sql = "SELECT * FROM NhaXuatBan";

            adapter = new SqlDataAdapter(sql, sqlCon);
            adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;  

            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);

            ds = new DataSet();
            adapter.Fill(ds, "NXB");

            dgvDanhSach.DataSource = ds.Tables["NXB"];

            DongKetNoi();
        }

        private void ClearForm()
        {
            txtMaXB.Text = "";
            txtTenXB.Text = "";
            txtDiaChi.Text = "";
            txtMaXB.Focus();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData();
            ClearForm();
        }

        private void btnThemDL_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text))
            {
                MessageBox.Show("Vui lòng nhập Mã NXB");
                return;
            }

            DataTable tbl = ds.Tables["NXB"];

            
            DataRow found = tbl.Rows.Find(txtMaXB.Text.Trim());
            if (found != null)
            {
                MessageBox.Show("Mã NXB đã tồn tại!");
                return;
            }

            DataRow row = tbl.NewRow();
            row["MaXB"] = txtMaXB.Text.Trim();
            row["TenXB"] = txtTenXB.Text.Trim();
            row["DiaChi"] = txtDiaChi.Text.Trim();
            tbl.Rows.Add(row);

            int result = adapter.Update(tbl);
            if (result > 0)
            {
                MessageBox.Show("Thêm thành công!");
                LoadData();
                ClearForm();
            }
            else
            {
                MessageBox.Show("Thêm thất bại!");
            }
        }
    }
}
