﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_BTtuan9
{
    public partial class Form4 : Form
    {
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\pppt-pmhdt-c#\Lab7\TranNgocPhuongLinh_1150080103_BTtuan9\QuanLyBanSach.mdf;Integrated Security=True";

        private SqlConnection sqlCon;
        private SqlDataAdapter adapter;
        private DataSet ds;

        public Form4()
        {
            InitializeComponent();
        }

        // ===== Helpers =====
        private void MoKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void LoadData()
        {
            MoKetNoi();
            adapter = new SqlDataAdapter("SELECT * FROM NhaXuatBan", sqlCon);
            adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey; // lấy PK

            // Tự sinh Insert/Update/Delete
            var builder = new SqlCommandBuilder(adapter);

            ds = new DataSet();
            adapter.Fill(ds, "NXB");

            dgvDanhSach.DataSource = ds.Tables["NXB"];
            DongKetNoi();
        }

        private DataRow GetSelectedRow()
        {
            if (dgvDanhSach.CurrentRow == null) return null;
            var drv = dgvDanhSach.CurrentRow.DataBoundItem as DataRowView;
            return drv?.Row;
        }

        // ===== Events =====
        private void Form4_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                var tbl = ds.Tables["NXB"];
                var rowUI = GetSelectedRow();
                if (rowUI == null)
                {
                    MessageBox.Show("Vui lòng chọn 1 dòng trong danh sách để xóa.");
                    return;
                }

                // tìm theo PK để chắc chắn
                var ma = rowUI["MaXB"].ToString();
                var row = tbl.Rows.Find(ma);
                if (row == null)
                {
                    MessageBox.Show("Không tìm thấy bản ghi cần xóa.");
                    return;
                }

                if (MessageBox.Show($"Xóa NXB có mã: {ma} ?", "Xác nhận",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                    return;

                row.Delete();                      // xóa trên DataTable
                int kq = adapter.Update(tbl);      // đẩy xuống DB

                if (kq > 0)
                {
                    MessageBox.Show("Xóa dữ liệu thành công!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Xóa dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu:\n" + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
