﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_BTtuan9
{
    public partial class Form3 : Form
    {
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\pppt-pmhdt-c#\Lab7\TranNgocPhuongLinh_1150080103_BTtuan9\QuanLyBanSach.mdf;Integrated Security=True";

        private SqlConnection sqlCon;
        private SqlDataAdapter adapter;
        private DataSet ds;

        public Form3()
        {
            InitializeComponent();
        }

        // ===== Helpers =====
        private void MoKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void LoadData()
        {
            MoKetNoi();
            string sql = "SELECT * FROM NhaXuatBan";
            adapter = new SqlDataAdapter(sql, sqlCon);

            
            adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);

            ds = new DataSet();
            adapter.Fill(ds, "NXB");

            dgvDanhSach.DataSource = ds.Tables["NXB"];
            DongKetNoi();
        }

        private void ClearEdit()
        {
            txtMaXB.Text = "";
            txtTenXB.Text = "";
            txtDiaChi.Text = "";
        }

        // ===== Events =====
        private void Form3_Load(object sender, EventArgs e)
        {
            LoadData();
            ClearEdit();
            txtMaXB.ReadOnly = true; 
        }

        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var rowView = dgvDanhSach.Rows[e.RowIndex].DataBoundItem as DataRowView;
            if (rowView == null) return;

            txtMaXB.Text = rowView["MaXB"].ToString();
            txtTenXB.Text = rowView["TenXB"].ToString();
            txtDiaChi.Text = rowView["DiaChi"].ToString();
        }

        private void btnChinhSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text))
            {
                MessageBox.Show("Hãy chọn 1 dòng ở danh sách để chỉnh sửa.");
                return;
            }

            try
            {
                DataTable tbl = ds.Tables["NXB"];
                DataRow row = tbl.Rows.Find(txtMaXB.Text.Trim());
                if (row == null)
                {
                    MessageBox.Show("Không tìm thấy bản ghi cần cập nhật.");
                    return;
                }

                row.BeginEdit();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = txtDiaChi.Text.Trim();
                row.EndEdit();

                int kq = adapter.Update(tbl);
                if (kq > 0)
                {
                    MessageBox.Show("Cập nhật thành công!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Cập nhật không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật:\n" + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
