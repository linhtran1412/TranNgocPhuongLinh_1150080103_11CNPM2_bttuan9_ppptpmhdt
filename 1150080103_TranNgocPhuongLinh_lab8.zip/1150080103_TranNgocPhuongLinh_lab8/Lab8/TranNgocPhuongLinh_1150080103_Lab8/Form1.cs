﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace TranNgocPhuongLinh_1150080103_Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
 
            this.Load += Form1_Load;
        }

        
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\pppt-pmhdt-c#\Lab8\TranNgocPhuongLinh_1150080103_Lab8\QuanLySinhVien.mdf;Integrated Security=True";

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                using (var con = new SqlConnection(strCon))
                {
                    con.Open();

                    var sql = "SELECT MaSV, TenSV, GioiTinh, NgaySinh, QueQuan, MaLop FROM SinhVien";
                    var da = new SqlDataAdapter(sql, con);
                    var ds = new DataSet();
                    da.Fill(ds, "SinhVien");

                    // Debug nhanh: xem số bản ghi
                    // MessageBox.Show(ds.Tables["SinhVien"].Rows.Count.ToString());

                    var rds = new ReportDataSource("dsSinhVien", ds.Tables["SinhVien"]);
                    reportViewer1.LocalReport.DataSources.Clear();
                    reportViewer1.LocalReport.DataSources.Add(rds);

                    // ✅ Trùng Default namespace + tên file RDLC
                    reportViewer1.LocalReport.ReportEmbeddedResource =
                        "TranNgocPhuongLinh_1150080103_Lab8.rptSinhVien.rdlc";

                    reportViewer1.RefreshReport();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị báo cáo: " + ex.Message);
            }
        }
    }
}
